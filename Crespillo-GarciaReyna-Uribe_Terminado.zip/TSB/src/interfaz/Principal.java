package interfaz;

public class Principal {
    public static void main(String[] args) {
        FrameEditor frame = new FrameEditor();
        frame.setVisible(true);
    
        //Archivo p = new Archivo ("Titulo", "¡Hola!, ¿Cómo va?.\n¿Esto es una loñcura!!?");
    }
}
